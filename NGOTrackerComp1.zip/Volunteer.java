public class Volunteer {
    int id;
    String name;
    String availability;

    public Volunteer(int id, String name, String availability) {
        this.id = id;
        this.name = name;
        this.availability = availability;
    }
}
