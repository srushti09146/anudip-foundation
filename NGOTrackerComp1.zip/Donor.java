public class Donor {
    int id;
    String name;
    String donationType;
    double amount;

    public Donor(int id, String name, String donationType, double amount) {
        this.id = id;
        this.name = name;
        this.donationType = donationType;
        this.amount = amount;
    }
}