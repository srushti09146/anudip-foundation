// Java code for FitnessLog.java
