// Java code for Book.java
