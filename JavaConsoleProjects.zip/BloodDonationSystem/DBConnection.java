// Java code for DBConnection.java
