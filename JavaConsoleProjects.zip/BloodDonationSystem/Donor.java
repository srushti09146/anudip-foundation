// Java code for Donor.java
