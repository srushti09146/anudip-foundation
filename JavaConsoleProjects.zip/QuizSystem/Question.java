// Java code for Question.java
